### Aritim-Dark: A theme for KDE, deeply inspired by Arc Dark colors and Ayu Dark

> This theme is based on the awesome [Sweet](https://store.kde.org/p/1294174/)theme

![image](preview/preview.png)
