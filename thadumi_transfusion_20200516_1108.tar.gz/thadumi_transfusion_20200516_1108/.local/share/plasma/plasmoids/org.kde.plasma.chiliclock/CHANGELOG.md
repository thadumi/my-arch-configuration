2019/06/23 - version 2.0

* massive options overhaul
* added support for:
  - spacing of active labels
  - vertical & horizontal offset for the whole clock
  - gain back control by choosing fixed or automatic font size
  - font size can be manually set when fixed is chosen  
  
* fixes known bugs:
  - labels now show inline under all circumstances
  - separator can now be activated or deactivated as intended
